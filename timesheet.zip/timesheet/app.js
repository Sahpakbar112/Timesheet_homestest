const express = require("express");
const bodyParser = require("body-parser");
const sequelize = require("./config/database");
const freelancerRoutes = require("./routes/freelancerRoutes");
const timesheetRoutes = require("./routes/timesheetRoutes");

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine", "ejs");

app.get("/", (req, res) => {
  res.render("index");
});

app.use("/api/freelancers", freelancerRoutes);
app.use("/api/timesheets", timesheetRoutes);

sequelize
  .sync({ force: false })
  .then(() => {
    app.listen(3000, () => {
      console.log("Server berjalan pada port 3000");
    });
  })
  .catch((err) => {
    console.error("Tidak dapat terhubung ke database:", err);
  });
