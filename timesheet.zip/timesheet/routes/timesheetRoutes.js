// routes/timesheetRoutes.js
const express = require("express");
const router = express.Router();
const timesheetController = require("../controllers/timesheetController");

router.get("/", timesheetController.getAllTimesheets);
router.post("/", timesheetController.createTimesheet);
router.get("/export", timesheetController.exportToCSV);
router.post(
  "/import",
  timesheetController.upload.single("file"),
  timesheetController.importFromCSV
);

module.exports = router;
