const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("db_timesheet", "root", "", {
  host: "localhost",
  dialect: "mysql",
  logging: false,
});

module.exports = sequelize;
