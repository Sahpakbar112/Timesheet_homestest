const sequelize = require("./config/database");
const Freelancer = require("./models/Freelancer");
const Timesheet = require("./models/Timesheet");
const { calculateOvertime } = require("./utils/overtimeCalculator");

const addRealData = async () => {
  try {
    await sequelize.sync({ force: true }); // This will drop and re-create all tables

    // Tambahkan data freelancer nyata
    const freelancers = await Freelancer.bulkCreate([
      { name: "Najib Rozzak", rate: 3 },
      { name: "Akbar Brown", rate: 4 },
      { name: "Saepul White", rate: 4 },
    ]);

    // Tambahkan data timesheet nyata
    const timesheets = [
      {
        freelancerId: freelancers[0].id,
        date: "2024-06-04",
        start_time: "08:00",
        end_time: "18:00",
      },
      {
        freelancerId: freelancers[1].id,
        date: "2024-06-05",
        start_time: "09:00",
        end_time: "19:00",
      },
      {
        freelancerId: freelancers[2].id,
        date: "2024-06-06",
        start_time: "07:00",
        end_time: "17:00",
      },
    ];

    for (const ts of timesheets) {
      const freelancer = await Freelancer.findByPk(ts.freelancerId);
      const { hoursWorked, overtimeHours, overtimeEarnings } =
        calculateOvertime(ts.start_time, ts.end_time, freelancer.rate);
      const totalEarnings = hoursWorked * freelancer.rate + overtimeEarnings;

      await Timesheet.create({
        freelancerId: ts.freelancerId,
        date: ts.date,
        start_time: ts.start_time,
        end_time: ts.end_time,
        total_hours: hoursWorked,
        overtime_hours: overtimeHours,
        total_earnings: totalEarnings,
        overtime_earnings: overtimeEarnings,
      });
    }

    console.log("Data nyata berhasil ditambahkan");
  } catch (error) {
    console.error("Gagal menambahkan data nyata:", error);
  } finally {
    await sequelize.close();
  }
};

addRealData();
