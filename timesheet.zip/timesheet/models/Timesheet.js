// // models/Timesheet.js
// const { DataTypes } = require("sequelize");
// const sequelize = require("../config/database");
// const Freelancer = require("./Freelancer");

// const Timesheet = sequelize.define("Timesheet", {
//   date: { type: DataTypes.DATEONLY, allowNull: false },
//   start_time: { type: DataTypes.TIME, allowNull: false },
//   end_time: { type: DataTypes.TIME, allowNull: false },
//   total_hours: { type: DataTypes.DECIMAL(5, 2), allowNull: false },
//   overtime_hours: { type: DataTypes.DECIMAL(5, 2), defaultValue: 0 },
//   total_earnings: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
//   overtime_earnings: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
// });

// Freelancer.hasMany(Timesheet);
// Timesheet.belongsTo(Freelancer);

// module.exports = Timesheet;

// models/Timesheet.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const Freelancer = require("./Freelancer");

const Timesheet = sequelize.define(
  "Timesheet",
  {
    freelancerId: {
      type: DataTypes.INTEGER,
      references: {
        model: Freelancer,
        key: "id",
      },
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    start_time: {
      type: DataTypes.TIME,
      allowNull: false,
    },
    end_time: {
      type: DataTypes.TIME,
      allowNull: false,
    },
    total_hours: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    overtime_hours: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    total_earnings: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    overtime_earnings: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
  },
  {
    tableName: "timesheets",
    timestamps: false,
  }
);

Freelancer.hasMany(Timesheet, { foreignKey: "freelancerId" });
Timesheet.belongsTo(Freelancer, { foreignKey: "freelancerId" });

module.exports = Timesheet;
