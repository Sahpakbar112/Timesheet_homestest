// // models/Freelancer.js
// const { DataTypes } = require("sequelize");
// const sequelize = require("../config/database");

// const Freelancer = sequelize.define("Freelancer", {
//   name: { type: DataTypes.STRING, allowNull: false },
//   rate: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
// });

// module.exports = Freelancer;
// models/Freelancer.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Freelancer = sequelize.define(
  "Freelancer",
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    rate: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
  },
  {
    tableName: "freelancers",
    timestamps: false,
  }
);

module.exports = Freelancer;
