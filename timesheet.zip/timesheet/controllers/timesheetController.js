const Timesheet = require("../models/Timesheet");
const Freelancer = require("../models/Freelancer");
const { calculateOvertime } = require("../utils/overtimeCalculator");
const json2csv = require("json2csv").parse;
const fs = require("fs");
const multer = require("multer");
const csvParser = require("csv-parser");

// Untuk upload file
const upload = multer({ dest: "uploads/" });

const getAllTimesheets = async (req, res) => {
  const timesheets = await Timesheet.findAll({ include: Freelancer });
  res.json(timesheets);
};

const createTimesheet = async (req, res) => {
  const { freelancerId, date, startTime, endTime } = req.body;
  const freelancer = await Freelancer.findByPk(freelancerId);
  if (!freelancer) {
    return res.status(404).json({ error: "Freelancer tidak ditemukan" });
  }

  const { hoursWorked, overtimeHours, overtimeEarnings } = calculateOvertime(
    startTime,
    endTime,
    freelancer.rate
  );
  const totalEarnings = hoursWorked * freelancer.rate + overtimeEarnings;

  const timesheet = await Timesheet.create({
    freelancerId,
    date,
    start_time: startTime,
    end_time: endTime,
    total_hours: hoursWorked,
    overtime_hours: overtimeHours,
    total_earnings: totalEarnings,
    overtime_earnings: overtimeEarnings,
  });

  res.json(timesheet);
};

const exportToCSV = async (req, res) => {
  const timesheets = await Timesheet.findAll({ include: Freelancer });
  const csv = json2csv(
    timesheets.map((ts) => ({
      id: ts.id,
      freelancer: ts.Freelancer.name,
      date: ts.date,
      start_time: ts.start_time,
      end_time: ts.end_time,
      total_hours: ts.total_hours,
      overtime_hours: ts.overtime_hours,
      total_earnings: ts.total_earnings,
      overtime_earnings: ts.overtime_earnings,
    }))
  );
  res.header("Content-Type", "text/csv");
  res.attachment("timesheets.csv");
  res.send(csv);
};

const importFromCSV = async (req, res) => {
  const results = [];
  fs.createReadStream(req.file.path)
    .pipe(csvParser())
    .on("data", (data) => results.push(data))
    .on("end", async () => {
      for (const row of results) {
        const freelancer = await Freelancer.findOrCreate({
          where: { name: row.freelancer },
          defaults: { rate: row.rate },
        });
        await Timesheet.create({
          freelancerId: freelancer[0].id,
          date: row.date,
          start_time: row.start_time,
          end_time: row.end_time,
          total_hours: row.total_hours,
          overtime_hours: row.overtime_hours,
          total_earnings: row.total_earnings,
          overtime_earnings: row.overtime_earnings,
        });
      }
      res.send("CSV berhasil diimpor");
    });
};

module.exports = {
  getAllTimesheets,
  createTimesheet,
  exportToCSV,
  importFromCSV,
  upload,
};
