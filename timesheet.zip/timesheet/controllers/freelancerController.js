// controllers/freelancerController.js
const Freelancer = require("../models/Freelancer");

exports.getAllFreelancers = async (req, res) => {
  const freelancers = await Freelancer.findAll();
  res.json(freelancers);
};

exports.createFreelancer = async (req, res) => {
  const { name, rate } = req.body;
  const freelancer = await Freelancer.create({ name, rate });
  res.json(freelancer);
};
