// utils/overtimeCalculator.js
const calculateOvertime = (startTime, endTime, rate) => {
  const start = new Date(`1970-01-01T${startTime}Z`);
  const end = new Date(`1970-01-01T${endTime}Z`);
  const hoursWorked = (end - start) / (1000 * 60 * 60);

  let overtimeHours = 0;
  if (hoursWorked > 8) {
    overtimeHours = hoursWorked - 8;
  }

  let overtimeEarnings = 0;
  if (overtimeHours > 0) {
    overtimeEarnings = overtimeHours * rate * 0.3;
  }

  return { hoursWorked, overtimeHours, overtimeEarnings };
};

module.exports = { calculateOvertime };
